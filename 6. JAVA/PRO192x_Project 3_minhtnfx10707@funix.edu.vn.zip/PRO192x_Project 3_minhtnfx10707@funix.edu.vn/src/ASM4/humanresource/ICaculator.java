package ASM4.humanresource;

 interface ICaculator {

   int caculateSalary();
}

